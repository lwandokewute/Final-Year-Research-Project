﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;
using System.Threading;

namespace CSharpControl2013
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            SetupChart();           
        }

        #region DAQLite Drivers WARNING! Do not Change

        EagleDaqII.EagleDAQ DAQ = new EagleDaqII.EagleDAQ();
        string fileName = "FlotationDataResults.CSV"; // "ScavengerInFlowRateID.CSV";
        string DAQName;
        bool Logging = false;
        long LogSamples=0;
        int chartPeriod = 84;
        double XValue;
        int inputType = 1;                  // controls input type
        int count = 0;                      // Timer variable   

        #endregion

        // Global control variables
       
        double yt_PlantOutput;              // Output of plant for position @ ADC INPUT 0 (Temperature output from sensor)
		double ut_PlantInput;               // Output of Controller to heater input   @ ADC INPUT 2	
        double scavengerValve;              // Valve input into the DAQ for the Scavenger valve
        double rougherValve;                // Valve input into the DAQ for the Rougher valve
        double scavengerLevel;              // Level reading of the Scavenger from the DAQ
        double rougherLevel;                // Level reading of the Rougher from the DAQ
        double scPercentage;                //scavenger level as percentage for writing to database
        double rgPercentage;                //rougher level as percentage for writing to database
        int state;

        double u_k;             // the desired output height in percentage to the system u(k|k)
        double u_k_1;           // control action action u(k-1|k) from the past by 1 sample
        double y_k;                 // controller output into the speed transfer function
        double y_k_1;           // controller output from the past by 1 sample

        double Y_K; //Error to desired speed transfer function
        double Y_K_1; // Error to desired transfer funtion from the past by 1 sampling

        double Av;
        double q0; // desired output flowrate
        double q0_1; //desired output flowrate from the past
        double q0Mapped;  // mapped output flowrate based on the valve value>PURPUSE: To eliminate errors with flowrate tracking
        Boolean TRIGGER;
        double Alarm_state;
        double resolve;
        double Gain=1;                      // Gain Default to one
        double Error;

        //--------------Alarm Control Constants--------------//
        int BUZZER_OFF = 8;                              // DI pin 4
        int LIGHT1_OFF = 0;                              // DI pin 3
        int LIGHT2_OFF = 0;                              // DI pin 2
        int FEED_PUMP_OFF = 0;                            // DI pin 1

        int BUZZER_ON = 0;                               // DI pin 4
        int LIGHT1_ON = 1;                               // DI pin 3
        int LIGHT2_ON = 2;                               // DI pin 2
        int FEED_PUMP_ON = 4;                            // DI pin 1


        // Database connection
        OleDbConnection FlotationDataConnection = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\\FlotationData.mdb;");

        private void FormLoad(object sender, EventArgs e)   // Connect to ADC/DAC
        {                        
            try 
            {
                string SerialNumber;
                DAQ.GetDaqName(out SerialNumber, out DAQName);
                textBoxDAQName.Text = DAQName;
                textBoxDAQSerial.Text = SerialNumber;
                u_k = 100;     //initial conditions of u_k
                u_k_1 = 0;
                y_k_1 = 0;
                Y_K_1 = 0;
                q0_1 = 0;

                rgPercentage = 0;
                scPercentage = 0;
                Alarm_state = 0;
                q0Mapped = 0;
                scavengerValve = 10;
                rougherValve = 10;
                TRIGGER = false;
                resolve = 1;
                state = LIGHT1_OFF + LIGHT2_OFF + FEED_PUMP_ON + BUZZER_OFF;
                DAQ.SendDigitalOutput(DAQName, state);
               

            }
            catch
            {
                MessageBox.Show("uDAQ not connected", "Cannot read uDAQ",
                                       MessageBoxButtons.OK, MessageBoxIcon.Error);
            }             
        }
        
        // Interrupt for timer
        private void Timer_Tick(object sender, EventArgs e)
        {
            string WriteData = "";
            double Increment = Convert.ToDouble(timer1.Interval) / 1000;
            XValue = XValue + Increment;
            //double XValue = count * timer1.Interval;


            double TimeElapsed = XValue;
            textBoxTimeElapsed.Clear();
            textBoxTimeElapsed.AppendText(TimeElapsed.ToString("0.00"));
            WriteData = TimeElapsed.ToString("0.00"); // Record into text string for data logging

            yt_PlantOutput = DAQ.GetInput(DAQName, 0);        // Read and Display yt @ ADC INPUT 0     ///////////////////////////////////////////////----FROM----/////////////////////////////////////////////////////        
            textBoxPlantOutput.Text = yt_PlantOutput.ToString("0.000");     // Display yt
           // WriteData += "," + yt_PlantOutput.ToString("0.000");            // Record into text string for data logging
            chart1.Series["yt_Output"].Points.AddXY(XValue, yt_PlantOutput); /////////////////////////////////////////////////////////////////////////----TO----//////////////////////////////////////////////////////

            string InputSignal = comboBoxInputSignal.Text;
            if (InputSignal == "EXTERNAL(DAQ-1)")
            {
                u_k = DAQ.GetInput(DAQName, 1);           // Read and Setpoint @ ADC INPUT 1 
            }
            else
            {
                try
                {
                    u_k = Convert.ToDouble(u_k);
                }
                catch
                { }
            }

            textBoxSetPoint.Text = u_k.ToString("0.000");                // Display Setpoint ////////////////////////////////////////////----FROM----///////////////////////////////////////////////////////////
            
            // WriteData += "," + rt_SetPoint.ToString("0.000");
            //chart1.Series["rt_setpoint"].Points.AddXY(XValue, u_k);   ////////////////////////////////////////////////////////////////////----TO----//////////////////////////////////////////////////////////

            double Velocity = DAQ.GetInput(DAQName, 2);           // Read and Setpoint @ ADC INPUT 2 ////////////////////////////////////////////----FROM----///////////////////////////////////////////////////////////
            textBoxMotorVelocity.Text = Velocity.ToString("0.000");
           // WriteData += "," + Velocity.ToString("0.000");
            chart1.Series["Motor Speed"].Points.AddXY(XValue, Velocity);  ////////////////////////////////////////////////////////////////////////----TO----//////////////////////////////////////////////////////////

            //SCAVENGER LEVEL READ
            scavengerLevel = DAQ.GetInput(DAQName, 1);
            textBox3.Text = scavengerLevel.ToString("0.000");

            //ROUGHER LEVEL READ
            rougherLevel = DAQ.GetInput(DAQName, 0);
            textBox4.Text = rougherLevel.ToString("0.000");


            //IN PERCENTAGE:
            scPercentage = Math.Round(((scavengerLevel / 9.166) * 100), 1);
            rgPercentage = Math.Round(((rougherLevel / 8.381) * 100), 1);

            // Controller
            //u_k =  Math.Round(u_k * 0.605, 2);

            Error = u_k - rgPercentage;
            textBox7.Text = Error.ToString("0.000");
            textBox8.Text = rgPercentage.ToString("0.000");

           
            y_k = 5824.05 * Error - 4499.4268 * u_k_1 + 0.21893 * y_k_1;  // PD controller output == y_k

            //setting prev values:
            u_k_1 = Error;
            y_k_1 = y_k;



            Y_K = 3.523375789 * Math.Pow(10, -3) * y_k + 0.889 * Y_K_1; //desired Height to desired tank speed difference equation

            //setting prev values:
            Y_K_1 = Y_K;

            Av = Y_K * Math.PI * Math.Pow(0.2244, 2); //desired tank volumetric flowrate rate

            q0 = 4.133935 * Math.Pow(10,- 4) - Av; //desired output flowrate
            q0 = -Av;

            
            ///////////////////////////////////////////////////saturation block /////////////////////////////////////////////////
            if (q0 >= 0.000503609)
            {
                q0 = 0.000503609;
            }
            else if (q0 <= 0)
            {
                q0 = 0;
            }
            else
            { }
           
            //remain the same
            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            ////////////////////////////////////////////////// Mechanical dynamics error elimination /////////////////////////////
           // double QError = q0 - q0Mapped;

          //  q0 = QError + q0_1;

            //setting the prevs q0, q(k-1|):
           // q0_1 = q0;


            ///////////////////////////////////////////////////// Nonlinear dynamics block ///////////////////////////////////////



            rougherValve = 7.7103626961019209 * Math.Pow(q0, 0) + -1.5730063773608577* Math.Pow(10, 5) * Math.Pow(q0, 1) + 2.0775800082966499* Math.Pow(10, 9) * Math.Pow(q0, 2) + -1.3782804539978047*Math.Pow(10, 13) * Math.Pow(q0, 3) + 4.5900443731293736* Math.Pow(10, 16) * Math.Pow(q0, 4) + -7.3917431224477090* Math.Pow(10, 19) * Math.Pow(q0, 5) + 4.5792735643275440* Math.Pow(10, 22)* Math.Pow(q0, 6);

            //rougher saturation block:
            if (rougherValve >= 10)
            {
                rougherValve = 10;
            }
            else if (rougherValve <= 0)
            {
                rougherValve = 0;
            }
            else
            { }


            textBox5.Text = rougherValve.ToString("0.000");
            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


            ////////////////////////////////////////// Nonlinear mapping /////////////////////////////////////////////////////////
            q0Mapped = 5.0588975845166826 * Math.Pow(10, -4) * Math.Pow(rougherValve, 0) + -1.9622608993345234 * Math.Pow(10, -4) * Math.Pow(rougherValve, 1) + 1.9519348821501374 * Math.Pow(10, -6) * Math.Pow(rougherValve, 2) + 1.2068765564194865 * Math.Pow(10, -5) * Math.Pow(rougherValve, 3) + -2.7360756497821430 * Math.Pow(10, -6) * Math.Pow(rougherValve, 4) + 2.4784907843095006 * Math.Pow(10, -7) * Math.Pow(rougherValve, 5) + -8.2329563695750027 * Math.Pow(10, -9) * Math.Pow(rougherValve, 6);
            
            //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


            double ut_Output = Gain * Error;

            // Send output to DAQ           
            string ControlLoop = comboBoxControlLoop.Text;
            if (ControlLoop == "OPEN")
            { ut_Output = y_k; }

                       
            DAQ.SendOutput(DAQName, 1, scavengerValve);
            DAQ.SendOutput(DAQName, 0, rougherValve);

            ut_PlantInput = ut_Output;        // Read and Display Controller Output    ////////////////////////////////////////////////----FROM----///////////////////////////////////////////////////////////////       
            textBoxControllerOutput_ut.Text = ut_PlantInput.ToString("0.000");
            //WriteData += "," + ut_PlantInput.ToString("0.000");
            chart1.Series["ut_Input"].Points.AddXY(XValue, ut_PlantInput); /////////////////////////////////////////////////////////////----TO----////////////////////////////////////////////////////////////////


            WriteData += "," + rougherLevel.ToString("0.000");
            WriteData += "," + rougherValve.ToString("0.000");
            WriteData += "," + scavengerLevel.ToString("0.000");
            WriteData += "," + scavengerValve.ToString("0.000");

            //for triggering ON or OFF the alarm

            if ((resolve == 0) && ((rgPercentage >= 80) || (scPercentage>=80)))
            {
                Alarm_state = 1;
            }
            else
            {
                Alarm_state = 0;
            }

            if ((Alarm_state == 1) && (TRIGGER == false))
            {
                // Create a thread and call a background method   
                // Start thread  
                timer2.Enabled = true;
                TRIGGER = true;
            }

            if ((resolve == 1) || ((rgPercentage < 80) && (scPercentage < 80)))
            {
                TRIGGER = false;
                timer2.Enabled = false;
                state = LIGHT1_OFF + LIGHT2_OFF + FEED_PUMP_ON + BUZZER_OFF;
                //DAQ.SendDigitalOutput(DAQName, 12);
                
            }
            if ((u_k < 30) && (rgPercentage <= 32))
            {
                //DAQ.SendDigitalOutput(DAQName, 8);
                TRIGGER = false;
                timer2.Enabled = false;
                state = LIGHT1_OFF + LIGHT2_OFF + FEED_PUMP_OFF + BUZZER_OFF;
                if (scPercentage > 80)
                {
                    rougherValve = 10;
                    
                }
            }
            if ((u_k < 30) && ((u_k - rgPercentage) >= 5))// when the error is more than 5%
            {
                state = LIGHT1_OFF + LIGHT2_OFF + FEED_PUMP_ON + BUZZER_OFF; ;
            }
            else { }

            DAQ.SendDigitalOutput(DAQName, state);



            #region // FOR LOGGING DATA
            if (Logging == true)
            {
                // Write data into file 
                // StreamWriter Datafile = new StreamWriter(fileName, true);
                // Datafile.WriteLine(WriteData);
                // Datafile.Close();
                // Show the sample count
                LogSamples++;
                textBoxLogSamples.Clear();
                textBoxLogSamples.Text = LogSamples.ToString();

                // to ACCESS DATA BASE
                LogToDatabase(TimeElapsed, u_k, yt_PlantOutput);
            }


            //if (XValue > 420)
            //{
            //    timer1.Enabled = false;
            //}

            #endregion
        }

        private void StartControl(object sender, EventArgs e)
        {            
            int interval;       // Enable and set timer            
            interval = Convert.ToInt16(textBoxInterval.Text);
            timer1.Interval = interval;
            buttonStartControl.Text = "CHART ON";
            textBoxInterval.Enabled = false;        // Disable appropriate text boxes
            //textBoxChartPeriod.Enabled = false;
            if (inputType == 0)
            {
                textBoxInputSignal.Enabled = false; 
                //textBoxStepLength.Enabled = false;
            }

            try
            {                
                timer1.Enabled = true;

            }
            catch
            {
                MessageBox.Show("DT9812 not connected", "Cannot read DT9812",
                                       MessageBoxButtons.OK, MessageBoxIcon.Error);
                timer1.Enabled = false;
            }

            SetupChart();      // Charts reset

           //chartPeriod = Convert.ToInt32(textBoxChartPeriod.Text) * 1000;      // Sets chart period

            count = 0;      // Reset counter

            // Initially Read Input from the TextBox
            try
            {
                u_k = Convert.ToDouble(textBox6.Text);
            }
            catch { }
            textBoxSetPoint.Text = u_k.ToString("0.0");          // Display rt 
        }

        private void StopControl(object sender, EventArgs e)
        {            
            timer1.Enabled = false;     // Disable timer
            buttonStartControl.Text = "CHART OFF";
            textBoxInterval.Enabled = true;
            textBoxInputSignal.Enabled = true;
            //textBoxStepLength.Enabled = true;
            //textBoxChartPeriod.Enabled = true;

            //output.SetSingleValueAsVolts(0, 0);     // Write ut to DAC Output 0	            
            textBoxPlantOutput.Text = "0";          // Set output text to 0;
            yt_PlantOutput = 0;            
            count = 0;      // Reset counter
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            //output.SetSingleValueAsVolts(0, 0);     // Write ut to DAC Output 0	            
            textBoxPlantOutput.Text = "0";      // Set output text to 0;
            
            this.Close();
        }

        #region DATA LOGGING 

        private void Startlogging(object sender, EventArgs e)
        {
            int interval = timer1.Interval;
            string sInterval = interval.ToString();
            FileStream Datafile1;
            
            buttonLogging.Text = "LOGGING ON";
            Logging = true;

            textBoxLogSamples.BackColor = System.Drawing.ColorTranslator.FromWin32(-16776961);
            textBoxLogSamples.ForeColor = System.Drawing.ColorTranslator.FromWin32(-1 );

            // Rec
            //   reate Create file              
            Datafile1 = new FileStream(fileName, FileMode.Create, FileAccess.Write);
            Datafile1.Close();

            StreamWriter Datafile = new StreamWriter(fileName, true);
            Datafile.WriteLine("DATA LOGGER INTERVAL @ " + sInterval + "ms");
            Datafile.WriteLine("TIME(s),RGH Level,RGH Valve,SCV Level,SCV Valve");
            Datafile.Close();

            // OPEN DATA BASE TO LOG DATA
            FlotationDataConnection.Open();
        }

        private void StopLogging(object sender, EventArgs e)
        {
            buttonLogging.Text = "START LOGGING";
            Logging = false;
            LogSamples = 0;
            textBoxLogSamples.BackColor = System.Drawing.ColorTranslator.FromWin32(-1);
            textBoxLogSamples.ForeColor = System.Drawing.ColorTranslator.FromWin32(-16777216);

            // CLOSE DATA BASE FOR LOGGING
            FlotationDataConnection.Close();
        }

        #endregion

        #region CHART SETUP
        private void button1_Click(object sender, EventArgs e)
        {
            SetupChart();
        }      
        public void SetupChart()
        {
            if (Convert.ToInt32(textBoxInterval.Text) < 20) textBoxInterval.Text = "20";        // Limit minimum time interval
            timer1.Interval = Convert.ToInt32(textBoxInterval.Text); // Setting timer interval

            XValue = 0;

            chart1.Series.Clear();                                   // Initialising chart components

            chart1.Series.Add("yt_Output");                          // Add series for yt and rt
            chart1.Series.Add("rt_SetPoint");
            chart1.Series.Add("ut_Input");
            chart1.Series.Add("Motor Speed");

            chart1.Series["yt_Output"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine; // Set type of graph to line
            chart1.Series["rt_SetPoint"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine;
            chart1.Series["ut_Input"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine;
            chart1.Series["Motor Speed"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine;
            // Assign colours to series
            chart1.Series["yt_Output"].Color = Color.Blue;
            chart1.Series["rt_SetPoint"].Color = Color.Red;
            chart1.Series["ut_Input"].Color = Color.Black;
            chart1.Series["Motor Speed"].Color = Color.Brown;

            chart1.ChartAreas[0].AxisY.Maximum = 10;                // Set Axis limits
            chart1.ChartAreas[0].AxisY.Minimum = -10;           
            chart1.ChartAreas[0].AxisY.MajorTickMark.Interval = 1;  // Settings for grids  setting on 1
            chart1.ChartAreas[0].AxisY.MajorGrid.Interval = 1;
            chart1.ChartAreas[0].AxisY.MinorGrid.Enabled = true;
            chart1.ChartAreas[0].AxisY.MinorGrid.Interval = 0.2;
            chart1.ChartAreas[0].AxisY.MinorGrid.LineColor = Color.LightGray;
            chart1.ChartAreas[0].AxisY.LabelStyle.Interval = 1;

            // X-Axis Settings
            chart1.ChartAreas[0].AxisX.MinorGrid.Enabled = true;
            chart1.ChartAreas[0].AxisX.MajorGrid.Enabled = true;
            chart1.ChartAreas[0].AxisX.MinorGrid.Interval = 1;
            chart1.ChartAreas[0].AxisX.MajorGrid.Interval = 5;
            chart1.ChartAreas[0].AxisX.MinorGrid.LineColor = Color.LightGray;
            chart1.ChartAreas[0].AxisX.MajorGrid.LineColor = Color.Black;
            chart1.ChartAreas[0].AxisX.LabelStyle.Interval = 5;

            chart1.ChartAreas[0].AxisX.Maximum = chartPeriod;
            chart1.ChartAreas[0].AxisX.Minimum = 0;


            //chart1.Series.Clear();      // Reset chart
            //chart1.Series.Add("yt");
            //chart1.Series.Add("rt");
            //chart1.Series["yt"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine;
            //chart1.Series["rt"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine;
            //chart1.Series["yt"].Color = Color.Blue;
            //chart1.Series["rt"].Color = Color.Red;
            //chart1.ChartAreas[0].AxisX.Maximum = chartPeriod;
            //chart1.ChartAreas[0].AxisX.Minimum = 0;


            count = 0;      // Reset counter
        }
        #endregion

        private void ChangeSValve(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                try
                {
                    scavengerValve = Convert.ToDouble(textBox2.Text);
                }
                catch { }
                textBoxSetPoint.Text = scavengerValve.ToString("0.0");
            }
        }
        private void ChangeRValve(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                try
                {
                    rougherValve = Convert.ToDouble(textBoxInputSignal.Text);
                }
                catch { }
                textBoxSetPoint.Text = rougherValve.ToString("0.0");
            }
        }

        // Change Gain
        private void ChangeSystemGain(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                Gain = Convert.ToDouble(textBoxSetGain.Text);                              
            }
        }

		private void RougherValvefn(object sender, EventArgs e)
		{
			try
			{
				rougherValve = Convert.ToDouble(textBoxInputSignal.Text);
			}
			catch { }
			textBoxSetPoint.Text = rougherValve.ToString("0.0");
		}

        private void ScavengerValvefn(object sender, EventArgs e)
        {
            try
            {
                scavengerValve = Convert.ToDouble(textBox2.Text);
            }
            catch { }
            textBoxSetPoint.Text = scavengerValve.ToString("0.0");
        }

        private void StepInputCommand(object sender, EventArgs e)
        {
            try
            {
                u_k = Convert.ToDouble(textBox6.Text);
            }
            catch { }
            textBoxSetPoint.Text = u_k.ToString("0.0");
        }

        #region ACCESS DATA BASE LOGGING

        public void LogToDatabase(double TimeInSeconds, double Input, double Output )
        {
            //string CommandText = "INSERT INTO FlotationDataTable ([Time_seconds],[Input],[Output]) VALUES (" +
            //  TimeInSeconds + "," + Input+"," + Output + ")";

            
            string CommandText = "UPDATE FlotationDataTable SET [Time_seconds] = "+ Math.Round(TimeInSeconds, 2) + " WHERE ID = 2";
            OleDbCommand InsertCommand = new OleDbCommand(CommandText, FlotationDataConnection);
            InsertCommand.ExecuteNonQuery();

            CommandText = "UPDATE FlotationDataTable SET [Scavenger_valve] = " + scavengerValve + " WHERE ID = 2";
            InsertCommand = new OleDbCommand(CommandText, FlotationDataConnection);
            InsertCommand.ExecuteNonQuery();

            CommandText = "UPDATE FlotationDataTable SET [Rougher_valve] = " + rougherValve + " WHERE ID = 2";
            InsertCommand = new OleDbCommand(CommandText, FlotationDataConnection);
            InsertCommand.ExecuteNonQuery();

            CommandText = "UPDATE FlotationDataTable SET [Scavenger_level] = " + scPercentage + " WHERE ID = 2";
            InsertCommand = new OleDbCommand(CommandText, FlotationDataConnection);
            InsertCommand.ExecuteNonQuery();

            CommandText = "UPDATE FlotationDataTable SET [Rougher_level] = " + rgPercentage + " WHERE ID = 2";
            InsertCommand = new OleDbCommand(CommandText, FlotationDataConnection);
            InsertCommand.ExecuteNonQuery();

            CommandText = "UPDATE FlotationDataTable SET [Error] = " + Math.Abs(Error) + " WHERE ID = 2";
            InsertCommand = new OleDbCommand(CommandText, FlotationDataConnection);
            InsertCommand.ExecuteNonQuery();


            string Command = "SELECT * FROM FlotationDataTable2 WHERE ID = 1";
            OleDbCommand SelectCommand = new OleDbCommand(Command, FlotationDataConnection);
            OleDbDataReader ReadData = SelectCommand.ExecuteReader();
            ReadData.Read();

            u_k = Convert.ToDouble(ReadData["Desired_Height"]);
            resolve = Convert.ToDouble(ReadData["Alarm_resolve"]);

            
        }

        #endregion

        private void AlarmSound(object sender, EventArgs e)
        {
            if (state == (LIGHT1_ON + LIGHT2_ON + FEED_PUMP_OFF + BUZZER_OFF))
            {
                state = LIGHT1_ON + LIGHT2_ON + FEED_PUMP_OFF + BUZZER_ON;
            }
            else
            {
                state = LIGHT1_ON + LIGHT2_ON + FEED_PUMP_OFF + BUZZER_OFF;
            }
            
            DAQ.SendDigitalOutput(DAQName, state);
                

        }
    }
}
